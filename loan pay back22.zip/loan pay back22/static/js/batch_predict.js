const batchFileInput = document.getElementById("batchFile");
const batchPredictBtn = document.getElementById("batchPredictBtn");

batchPredictBtn.addEventListener("click", async () => {
    const file = batchFileInput.files[0];
    if (!file) {
        alert("Please select a CSV file first!");
        return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
        const text = event.target.result;
        const lines = text.split("\n").filter(line => line.trim() !== "");
        const headers = lines[0].split(",");
        const users = lines.slice(1).map(line => {
            const values = line.split(",");
            const obj = {};
            headers.forEach((h, i) => {
                obj[h.trim()] = values[i].trim();
                // Convert numeric fields
                if (["age","loan_amount","annual_income","debt_to_income_ratio","credit_score","interest_rate"].includes(h.trim())) {
                    obj[h.trim()] = Number(values[i].trim());
                }
            });
            return obj;
        });

        for (const user of users) {
            try {
                const response = await fetch("/predict", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(user)
                });

                if (!response.ok) throw new Error(`Server returned ${response.status}`);
                const result = await response.json();

               
                if ($.fn.DataTable.isDataTable("#logsTable")) {
                    const dt = $('#logsTable').DataTable();
                    dt.row.add([
                        user.full_name || "-",
                        result.prediction,
                        (result.probability * 100).toFixed(2),
                        user.loan_amount,
                        user.annual_income,
                        user.debt_to_income_ratio,
                        user.credit_score,
                        user.interest_rate,
                        user.gender,
                        user.marital_status,
                        user.education_level,
                        user.employment_status,
                        user.loan_purpose,
                        user.grade_subgrade,
                        new Date().toLocaleString()
                    ]).draw(false);
                }

            } catch (error) {
                console.error("Error predicting batch:", error);
            }
        }

        alert("Batch prediction completed!");
    };

    reader.readAsText(file);
});
