from flask import Flask, request, jsonify, render_template, make_response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import pandas as pd
import joblib
import io
import csv
import os

app = Flask(__name__)


model = joblib.load("best_loan_model.pkl")
scaler = joblib.load("scaler.pkl")
feature_columns = joblib.load("feature_columns.pkl")


LOG_FILE = "prediction_logs.csv"


app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:@localhost:3306/loan_prediction"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


class Prediction(db.Model):
    __tablename__ = "predictions"

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    full_name = db.Column(db.String(100))
    prediction = db.Column(db.String(20))
    probability = db.Column(db.Float)
    loan_amount = db.Column(db.Float)
    annual_income = db.Column(db.Float)
    debt_to_income_ratio = db.Column(db.Float)
    credit_score = db.Column(db.Float)
    interest_rate = db.Column(db.Float)
    gender = db.Column(db.String(20))
    marital_status = db.Column(db.String(20))
    education_level = db.Column(db.String(50))
    employment_status = db.Column(db.String(50))
    loan_purpose = db.Column(db.String(50))
    grade_subgrade = db.Column(db.String(10))
    timestamp = db.Column(db.String(50))


with app.app_context():
    db.create_all()


def log_to_csv(row):
    file_exists = os.path.isfile(LOG_FILE)

    with open(LOG_FILE, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=row.keys())
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)


@app.route("/")
def home():
    return render_template("index.html")



@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()

    ml_input = {}

    for col in feature_columns:
        value = data.get(col, 0)

        try:
            ml_input[col] = float(value)
        except (ValueError, TypeError):
            ml_input[col] = 0.0

    input_df = pd.DataFrame([ml_input])
    input_scaled = scaler.transform(input_df)

    probability = model.predict_proba(input_scaled)[0][1]
    prediction_text = "Will Repay" if probability >= 0.6 else "Will Not Repay"

    log_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "full_name": data.get("full_name", ""),
        "loan_amount": float(data.get("loan_amount", 0)),
        "annual_income": float(data.get("annual_income", 0)),
        "debt_to_income_ratio": float(data.get("debt_to_income_ratio", 0)),
        "credit_score": float(data.get("credit_score", 0)),
        "interest_rate": float(data.get("interest_rate", 0)),
        "gender": data.get("gender", ""),
        "marital_status": data.get("marital_status", ""),
        "education_level": data.get("education_level", ""),
        "employment_status": data.get("employment_status", ""),
        "loan_purpose": data.get("loan_purpose", ""),
        "grade_subgrade": data.get("grade_subgrade", ""),
        "prediction": prediction_text,
        "probability": round(probability, 4)
    }

    
    log_to_csv(log_data)
    db.session.add(Prediction(**log_data))
    db.session.commit()

    return jsonify({
        "prediction": prediction_text,
        "probability": round(probability, 4)
    })


@app.route("/batch_predict", methods=["POST"])
def batch_predict():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    try:
        df = pd.read_csv(file)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    required_cols = feature_columns + ["full_name"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        return jsonify({"error": f"Missing columns: {missing}"}), 400

    input_scaled = scaler.transform(df[feature_columns])
    probs = model.predict_proba(input_scaled)[:, 1]

    df["prediction"] = ["Will Repay" if p >= 0.6 else "Will Not Repay" for p in probs]
    df["probability"] = probs.round(4)
    df["timestamp"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    records = []

    for _, row in df.iterrows():
        record = {
            "full_name": row["full_name"],
            "prediction": row["prediction"],
            "probability": float(row["probability"]),
            "loan_amount": float(row["loan_amount"]),
            "annual_income": float(row["annual_income"]),
            "debt_to_income_ratio": float(row["debt_to_income_ratio"]),
            "credit_score": float(row["credit_score"]),
            "interest_rate": float(row["interest_rate"]),
            "gender": row["gender"],
            "marital_status": row["marital_status"],
            "education_level": row["education_level"],
            "employment_status": row["employment_status"],
            "loan_purpose": row["loan_purpose"],
            "grade_subgrade": row["grade_subgrade"],
            "timestamp": row["timestamp"]

        }

        log_to_csv(record)
        records.append(Prediction(**record))

    db.session.bulk_save_objects(records)
    db.session.commit()

    return jsonify(df.to_dict(orient="records"))


@app.route("/download_sample_users")
def download_sample_users():
    sample_users = [
        {"full_name":"Bruce Melodie","gender":"Male","marital_status":"Single","education_level":"Bachelor","employment_status":"Employed","loan_amount":12000,"annual_income":95000,"debt_to_income_ratio":15,"credit_score":710,"interest_rate":4.5,"loan_purpose":"Business","grade_subgrade":"A1"},
        {"full_name":"Meddy","gender":"Male","marital_status":"Married","education_level":"Bachelor","employment_status":"Self-Employed","loan_amount":15000,"annual_income":100000,"debt_to_income_ratio":18,"credit_score":720,"interest_rate":5.0,"loan_purpose":"Personal","grade_subgrade":"A2"}
    ]

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=sample_users[0].keys())
    writer.writeheader()
    writer.writerows(sample_users)
    output.seek(0)

    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=sample_users.csv"
    response.headers["Content-Type"] = "text/csv"
    return response


@app.route("/logs", methods=["GET"])
def get_logs():
    predictions = Prediction.query.order_by(Prediction.id.desc()).limit(20).all()

    return jsonify([
        {
            "timestamp": p.timestamp,
            "full_name": p.full_name,
            "loan_amount": p.loan_amount,
            "annual_income": p.annual_income,
            "debt_to_income_ratio": p.debt_to_income_ratio,
            "credit_score": p.credit_score,
            "interest_rate": p.interest_rate,
            "gender": p.gender,
            "marital_status": p.marital_status,
            "education_level": p.education_level,
            "employment_status": p.employment_status,
            "loan_purpose": p.loan_purpose,
            "grade_subgrade": p.grade_subgrade,
            "prediction": p.prediction,
            "probability": p.probability
        } for p in predictions
    ])


if __name__ == "__main__":
    app.run(debug=True)