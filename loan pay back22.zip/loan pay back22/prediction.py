import joblib
import pandas as pd
import numpy as np
from datetime import datetime


model = joblib.load("best_loan_model.pkl")
scaler = joblib.load("scaler.pkl")
feature_columns = joblib.load("feature_columns.pkl")

print("Model and scaler loaded successfully")
print(f"Expected features: {feature_columns}")


sample_data = [
    {
        'full_name': 'Ahmed Hassan',
        'age': 40,
        'gender': 'Male',
        'marital_status': 'Married',
        'education_level': 'Bachelor',
        'employment_status': 'Self-employed',
        'loan_amount': 18000,
        'annual_income': 65000,
        'debt_to_income_ratio': 28.0,
        'interest_rate': 9.0,
        'credit_score': 710,
        'loan_purpose': 'Business',
        'grade_subgrade': 'A2'
    },
    {
        'full_name': 'Amina Yusuf',
        'age': 27,
        'gender': 'Female',
        'marital_status': 'Single',
        'education_level': 'Master',
        'employment_status': 'Employed',
        'loan_amount': 22000,
        'annual_income': 70000,
        'debt_to_income_ratio': 26.5,
        'interest_rate': 7.8,
        'credit_score': 745,
        'loan_purpose': 'Education',
        'grade_subgrade': 'A1'
    }
]



data = pd.DataFrame(sample_data)




metadata_columns = ['full_name']
metadata = data[metadata_columns].copy() if 'full_name' in data.columns else None


feature_data = data.drop(columns=[col for col in metadata_columns if col in data.columns], errors='ignore')


categorical_columns = ['gender', 'marital_status', 'education_level', 'employment_status', 'loan_purpose', 'grade_subgrade']


feature_data_encoded = pd.get_dummies(feature_data, columns=categorical_columns, drop_first=False)

print(f"\nAfter encoding, features: {list(feature_data_encoded.columns)}")


missing_features = set(feature_columns) - set(feature_data_encoded.columns)
if missing_features:
    print(f"Adding missing features: {missing_features}")
    for feature in missing_features:
        feature_data_encoded[feature] = 0


extra_features = set(feature_data_encoded.columns) - set(feature_columns)
if extra_features:
    print(f"Removing extra features: {extra_features}")
    feature_data_encoded = feature_data_encoded.drop(columns=list(extra_features))


X = feature_data_encoded[feature_columns]

print(f"\nPreparing {len(X)} records for prediction...")
print(f"Features shape: {X.shape}")
print(f"Sample of prepared features:\n{X.head()}")


X_scaled = scaler.transform(X)


predictions = model.predict(X_scaled)


try:
    prediction_probabilities = model.predict_proba(X_scaled)
    print("Prediction probabilities generated successfully")
except AttributeError:
    prediction_probabilities = None
    print("Model doesn't support probability predictions")


results = {
    'predictions': predictions,
    'probabilities': prediction_probabilities,
    'feature_columns': feature_columns,
    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
    'num_predictions': len(predictions)
}


joblib.dump(results, "predictions.pkl")
print(f"\n✓ Predictions saved to predictions.pkl")
print(f"✓ Number of predictions: {len(predictions)}")


output_df = pd.DataFrame({
    'prediction': predictions,
    'prediction_label': ['Will Repay' if p == 1 else 'Will Not Repay	' for p in predictions]
})


if metadata is not None:
    for col in metadata.columns:
        output_df[col] = metadata[col].values


if prediction_probabilities is not None:
    output_df['probability_default'] = prediction_probabilities[:, 0]
    output_df['probability_payback'] = prediction_probabilities[:, 1]
    output_df['confidence'] = np.max(prediction_probabilities, axis=1)


for col in feature_data.columns:
    if col not in output_df.columns:
        output_df[col] = feature_data[col].values


output_df['prediction_timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')


output_df.to_csv("predictions.csv", index=False)
print(f"✓ Predictions also saved to predictions.csv")


print("\n" + "="*80)
print("SAMPLE PREDICTIONS:")
print("="*80)
for idx, row in output_df.head().iterrows():
    print(f"\nRecord {idx + 1}:")
    if 'full_name' in row:
        print(f"  Name: {row['full_name']}")
    print(f"  Prediction: {row['prediction_label']}")
    if 'probability_payback' in row:
        print(f"  Payback Probability: {row['probability_payback']*100:.2f}%")
        print(f"  Confidence: {row['confidence']*100:.2f}%")

print("\n" + "="*80)
print("Prediction summary:")
if prediction_probabilities is not None:
    payback_count = np.sum(predictions == 1)
    default_count = np.sum(predictions == 0)
    print(f"  - Will Repay: {payback_count} ({payback_count/len(predictions)*100:.2f}%)")
    print(f"  - Will Not Repay: {default_count} ({default_count/len(predictions)*100:.2f}%)")
print("="*80)